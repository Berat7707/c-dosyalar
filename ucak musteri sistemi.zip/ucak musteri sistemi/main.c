#include <stdio.h>
#include<string.h>
struct ucus{
    int ucus_numara;
    char kalkis_yeri[21];
    char varis_yeri[21];
    int kalkis_saati;
    int kalkis_dakikasi;
    int koltuk_kapasitesi;
    int bos_koltuk_sayisi;
    float bilet_fiyat;
} ucuslar;

void listeleme(int ucus_kodu)
{
   float doluluk_orani;
   FILE *dat_dosya;
   FILE *txt_dosya,*gecici;
dat_dosya = fopen("C:\\Users\\90546\\Desktop\\proje\\ucus (1).dat", "rb");
    if (dat_dosya  == NULL)
    {
      printf("Dosya acilamayor.");

    }
    else
    {
        while (fread(&ucuslar, sizeof(struct ucus), 1, dat_dosya) == 1)
        {
            if(ucuslar.ucus_numara==ucus_kodu)
            {
                doluluk_orani=(float)(((ucuslar.koltuk_kapasitesi-ucuslar.bos_koltuk_sayisi)*100))/ucuslar.koltuk_kapasitesi;
            printf("Ucus No\t Kalkis Yeri\tVaris Yeri\tZamani\t\tKapasite\tBos koltuk\tDoluluk %\n");
            printf("------   ----------    -----------    ---------        ----------       -------       ----------\n");
                printf(" %d\t   %s\t  %s\t%02d:%02d\t\t  %02d\t         %02d\t        %.2f\n",
                       ucuslar.ucus_numara, ucuslar.kalkis_yeri, ucuslar.varis_yeri,
                       ucuslar.kalkis_saati, ucuslar.kalkis_dakikasi, ucuslar.koltuk_kapasitesi,ucuslar.bos_koltuk_sayisi,doluluk_orani);

            }
        }
    }
                fclose(dat_dosya);

}
void satilan_bilet(int ucus_kodu)
{
    int aranan_kod,sayac=0;
    int no;
    int sayi,tc,bilet_tutar,toplam_tutar=0;
    float bilet_fiyat,ortalama_bilet;
    float doluluk_orani;
    int ucus_kod;
    char satir[100];
   FILE *dat_dosya;
   FILE *txt_dosya,*gecici;

    dat_dosya = fopen("C:\\Users\\90546\\Desktop\\proje\\ucus (1).dat", "rb");

    if (dat_dosya  == NULL)
    {
      printf("Dosya acilamayor.");

    }
    else
        {
        while (fread(&ucuslar, sizeof(struct ucus), 1, dat_dosya) == 1)
            {

            if(ucuslar.ucus_numara==ucus_kodu)
                {
                                 doluluk_orani=(float)(((ucuslar.koltuk_kapasitesi-ucuslar.bos_koltuk_sayisi)*100))/ucuslar.koltuk_kapasitesi;

          printf("Ucus No\t Kalkis Yeri\tVaris Yeri\tZamani\t\tKapasite\tBos koltuk\tDoluluk %\n");
            printf("------   ----------    -----------    ---------        ----------       -------       ----------\n");
                printf(" %d\t   %s\t  %s\t%02d:%02d\t\t  %02d\t         %02d\t        %.2f\n",
                       ucuslar.ucus_numara, ucuslar.kalkis_yeri, ucuslar.varis_yeri,
                       ucuslar.kalkis_saati, ucuslar.kalkis_dakikasi, ucuslar.koltuk_kapasitesi,ucuslar.bos_koltuk_sayisi,doluluk_orani);
               }

            }
        }
            fclose(dat_dosya);
            txt_dosya=fopen("bilet.txt","rb");
while (fgets(satir, sizeof(satir), txt_dosya))
    {
        sscanf(satir, "%d %d %d", &sayi,&tc,&bilet_tutar);
        if (sayi == ucus_kodu)
        {
            printf("%s", satir);
            toplam_tutar+=bilet_tutar;
             sayac++;
        }
    }
    printf("Toplam bilet sayisi:%d\n",sayac);
    printf("toplam tutar:%d\n",toplam_tutar);
    ortalama_bilet=(float)toplam_tutar/sayac;
    printf("Ortalama bilet fiyati:%.2f",ortalama_bilet);
    fclose(txt_dosya);
}
void kalkis_listeleme(FILE*dat_dosya)
{
    char kalkis[20];
   float doluluk_orani;
if (dat_dosya  == NULL)
    {
      printf("Dosya acilamayor.");

    }

else
    {  printf("Lutfen kalkis yerini yaziniz:");
        scanf("%s",&kalkis);
      while (fread(&ucuslar, sizeof(struct ucus), 1, dat_dosya) == 1)
      {
            if(strcmp(kalkis,ucuslar.kalkis_yeri)==0)
            {
            doluluk_orani=(float)(((ucuslar.koltuk_kapasitesi-ucuslar.bos_koltuk_sayisi)*100))/ucuslar.koltuk_kapasitesi;
            printf("Ucus No\t Kalkis Yeri\tVaris Yeri\tZamani\t\tKapasite\tBos koltuk\tDoluluk %\n");
            printf("------   ----------    -----------    ---------        ----------       -------       ----------\n");
                printf(" %d\t   %s\t  %s\t%02d:%02d\t\t  %02d\t         %02d\t        %.2f\n",
                       ucuslar.ucus_numara, ucuslar.kalkis_yeri, ucuslar.varis_yeri,
                       ucuslar.kalkis_saati, ucuslar.kalkis_dakikasi, ucuslar.koltuk_kapasitesi,ucuslar.bos_koltuk_sayisi,doluluk_orani);
            }

      }

    }

fclose(dat_dosya);
}
void yolcu_bileti(FILE*txt_dosya,FILE*dat_dosya)
{   int tc_kimlik;
    float doluluk_orani,bilet_fiyat;
    int no,aranan_kod;
    printf("Lutfen tc'nizi giriniz");
    scanf("%d",&tc_kimlik);
while(fscanf(txt_dosya,"%d %d %f ",&aranan_kod,&no,&bilet_fiyat)!=EOF)
    {
    if (tc_kimlik == no)
        {
        printf("Aranan kod: %d\n", aranan_kod);
        fseek(dat_dosya, 0, SEEK_SET);
        while (fread(&ucuslar, sizeof(struct ucus), 1, dat_dosya) == 1)
            {
                    if (ucuslar.ucus_numara == aranan_kod)
                 {
              doluluk_orani=(float)(((ucuslar.koltuk_kapasitesi-ucuslar.bos_koltuk_sayisi)*100))/ucuslar.koltuk_kapasitesi;
              printf("Ucus No\t Kalkis Yeri\tVaris Yeri\tZamani\t\tFiyati\t  Doluluk %\n");
              printf("------   ----------    -----------    ---------        --------   -------\n");
              printf(" %d\t   %s\t  %s\t%02d:%02d\t\t%.2f\t  %.2f\n",
                       ucuslar.ucus_numara, ucuslar.kalkis_yeri, ucuslar.varis_yeri,
                       ucuslar.kalkis_saati, ucuslar.kalkis_dakikasi, ucuslar.bilet_fiyat,doluluk_orani);
                 }
            }

        }



    }

}
int main() {
    printf("Lutfen yapmak istediginiz islemi seciniz.\n");
    printf("Ucus bilgilerini gormek istiyorsaniz 1'e basin.\n");
    printf("Ucus bilgilerini ve satilan biletleri gormek istiyorsaniz 2'ye basin.\n");
    printf("Kalkis yerine gore listelemek icin 3'e basin.\n");
    printf("Koltuk doluluk oranina gore listelemek icn 4' basin.\n");
    printf("Sahip oldugunuz biletleri goruntulemek icin 5'e basin\n");
    int ucus_kodu;
    float doluluk_orani;
    int tc_kimlik,b,c;
    float dizi[50];
    int bos[50];
    int secim,i,kucuk;
   FILE *dat_dosya;
   FILE *txt_dosya,*gecici;
dat_dosya = fopen("C:\\Users\\90546\\Desktop\\proje\\ucus (1).dat", "rb");
 scanf("%d",&secim);
    switch(secim)
    {
        case 1:
            printf("ucus numarasý girin:\n");
            scanf("%d",&ucus_kodu);
            listeleme(ucus_kodu);

                    break;
case 2:
        printf("ucus numarasi girin:\n");
        scanf("%d",&ucus_kodu);
        satilan_bilet(ucus_kodu);
            break;


        case 3:

            dat_dosya = fopen("C:\\Users\\90546\\Desktop\\proje\\ucus (1).dat", "rb");
            kalkis_listeleme(dat_dosya);

    break;
       case 4:
           printf("doluluk oranina gore listeleme\n");
           dat_dosya=fopen("C:\\Users\\90546\\Desktop\\proje\\ucus (1).dat","rb");
           i=0;
           while(fread(&ucuslar, sizeof(struct ucus), 1, dat_dosya)==1){

           	if(ucuslar.ucus_numara>0){
           	if(((float)(((ucuslar.koltuk_kapasitesi-ucuslar.bos_koltuk_sayisi)*100))/ucuslar.koltuk_kapasitesi)<50){
            dizi[i]=(float)(((ucuslar.koltuk_kapasitesi-ucuslar.bos_koltuk_sayisi)*100))/ucuslar.koltuk_kapasitesi;
            bos[i]=ucuslar.bos_koltuk_sayisi;
            i++;}}
           }
            fclose(dat_dosya);
           c=i;
           for(i=0;i<c;i++){
           	for(b=0;b<i;b++){
           		if(dizi[i]<dizi[b]){
           			kucuk=dizi[i];
           			dizi[i]=dizi[b];
                    dizi[b]=kucuk;

                    kucuk=bos[i];
                    bos[i]=bos[b];
					bos[b]=kucuk;

				   }
				   if(dizi[i]==dizi[b]){
                       	if(bos[i]>bos[b]){
                       		kucuk=bos[i];
                    bos[i]=bos[b];
					bos[b]=kucuk;

						   }
					   }
}

			   }
 printf("Ucus No\t\tKalkis Yeri\t\tVaris Yeri\t\tZamani\t\tKapasite\t bos koltuk\t Doluluk %\n");

            for(i=0;i<c;i++){


                    dat_dosya=fopen("C:\\Users\\90546\\Desktop\\proje\\ucus (1).dat","rb");
                while(fread(&ucuslar, sizeof(struct ucus), 1, dat_dosya)==1){
           	   if((ucuslar.bos_koltuk_sayisi==bos[i])&&(dizi[i]==(float)(((ucuslar.koltuk_kapasitesi-ucuslar.bos_koltuk_sayisi)*100))/ucuslar.koltuk_kapasitesi)){
                             
              printf("------   ----------    -----------    ---------        --------   -------\n");
              printf("%d\t\t%s\t\t\t%s\t\t\t%02d:%02d\t\t%d\t\t%d\t\t%.2f\n",
                       ucuslar.ucus_numara, ucuslar.kalkis_yeri, ucuslar.varis_yeri,
                       ucuslar.kalkis_saati, ucuslar.kalkis_dakikasi,ucuslar.koltuk_kapasitesi,ucuslar.bos_koltuk_sayisi,(float)dizi[i]);


                      break;


		   }}

		   fclose(dat_dosya);
		   }




break;


case 5:
    txt_dosya=fopen("bilet.txt","rb") ;
    dat_dosya = fopen("C:\\Users\\90546\\Desktop\\proje\\ucus (1).dat", "rb");
    yolcu_bileti(txt_dosya,dat_dosya);


        break;


}




   return 0;
}
